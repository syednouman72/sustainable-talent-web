import * as React from "react";

declare function FooterComponentV6(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element