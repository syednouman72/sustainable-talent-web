import * as React from "react";

declare function HeroComponentV10(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element