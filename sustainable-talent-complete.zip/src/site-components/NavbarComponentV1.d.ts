import * as React from "react";

declare function NavbarComponentV1(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element