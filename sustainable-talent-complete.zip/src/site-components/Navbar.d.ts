import * as React from "react";

declare function Navbar(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element