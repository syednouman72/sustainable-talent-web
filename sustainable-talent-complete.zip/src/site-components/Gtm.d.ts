import * as React from "react";

declare function Gtm(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element