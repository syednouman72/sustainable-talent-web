import * as React from "react";

declare function BannerComponentV5(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element