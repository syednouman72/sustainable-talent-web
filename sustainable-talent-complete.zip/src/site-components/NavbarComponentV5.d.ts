import * as React from "react";

declare function NavbarComponentV5(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element