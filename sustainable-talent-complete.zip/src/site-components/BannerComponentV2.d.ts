import * as React from "react";

declare function BannerComponentV2(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element