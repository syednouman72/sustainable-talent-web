import * as React from "react";

declare function HeroComponentV8(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element