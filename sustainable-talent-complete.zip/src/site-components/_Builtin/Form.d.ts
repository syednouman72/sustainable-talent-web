declare global {
    interface Window {
        grecaptcha: any;
    }
}
export declare const FormWrapper: any;
export declare const FormForm: any;
export declare const FormBlockLabel: any;
export declare const FormTextInput: any;
export declare const FormTextarea: any;
export declare const FormInlineLabel: any;
export declare const FormCheckboxWrapper: any;
export declare const FormRadioWrapper: any;
export declare const FormBooleanInput: any;
export declare const FormCheckboxInput: any;
export declare const FormRadioInput: any;
export declare const FormFileUploadWrapper: any;
export declare const _FormFileUploadWrapper: any;
export declare const FormFileUploadDefault: any;
export declare const FormFileUploadInput: any;
export declare const FormFileUploadLabel: any;
export declare const FormFileUploadText: any;
export declare const FormFileUploadInfo: any;
export declare const FormFileUploadUploading: any;
export declare const FormFileUploadUploadingBtn: any;
export declare const FormFileUploadUploadingIcon: any;
export declare const FormFileUploadSuccess: any;
export declare const FormFileUploadFile: any;
export declare const FormFileUploadFileName: any;
export declare const FormFileUploadRemoveLink: any;
export declare const FormFileUploadError: any;
export declare const FormFileUploadErrorMsg: any;
export declare const FormButton: any;
export declare const SearchForm: any;
export declare const SearchInput: any;
export declare const SearchButton: any;
export declare const FormSuccessMessage: any;
export declare const FormErrorMessage: any;
export declare const FormSelect: any;
export declare const FormReCaptcha: any;
