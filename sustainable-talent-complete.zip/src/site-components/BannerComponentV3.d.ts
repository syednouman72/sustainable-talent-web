import * as React from "react";

declare function BannerComponentV3(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element