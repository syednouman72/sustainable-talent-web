import * as React from "react";

declare function NavbarComponentV3(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element