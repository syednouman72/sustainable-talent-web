"use client";
import React from "react";
import * as _Builtin from "./_Builtin";

export function Gtm(
    {
        as: _Component = _Builtin.HtmlEmbed
    }
) {
    return (
        <_Component
            value="%3C!--%20Google%20Tag%20Manager%20(noscript)%20--%3E%0A%3Cnoscript%3E%3Ciframe%20src%3D%22https%3A%2F%2Fwww.googletagmanager.com%2Fns.html%3Fid%3DGTM-T67L6HDB%22%0Aheight%3D%220%22%20width%3D%220%22%20style%3D%22display%3Anone%3Bvisibility%3Ahidden%22%3E%3C%2Fiframe%3E%3C%2Fnoscript%3E%0A%3C!--%20End%20Google%20Tag%20Manager%20(noscript)%20--%3E" />
    );
}