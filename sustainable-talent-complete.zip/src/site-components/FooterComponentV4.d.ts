import * as React from "react";

declare function FooterComponentV4(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element