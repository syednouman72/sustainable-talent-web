import * as React from "react";

declare function PopUp(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element