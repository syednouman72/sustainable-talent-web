import * as React from "react";

declare function NavbarComponentV6(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element