import * as React from "react";

declare function SectionTrustedMarquee(
    props: {
        as?: React.ElementType;
        variant?: "Base" | "Simple (Brand Trust)";
    }
): React.JSX.Element