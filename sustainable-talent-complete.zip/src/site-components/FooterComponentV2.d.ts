import * as React from "react";

declare function FooterComponentV2(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element