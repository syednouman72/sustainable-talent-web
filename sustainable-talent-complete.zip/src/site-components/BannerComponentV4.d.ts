import * as React from "react";

declare function BannerComponentV4(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element