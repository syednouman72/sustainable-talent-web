import * as React from "react";

declare function FooterComponentV3(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element