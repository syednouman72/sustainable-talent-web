import * as React from "react";

declare function HeroComponentV4(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element