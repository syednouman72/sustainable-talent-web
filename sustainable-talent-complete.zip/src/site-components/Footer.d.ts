import * as React from "react";

declare function Footer(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element