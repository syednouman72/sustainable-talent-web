import * as React from "react";

declare function NavbarComponentV2(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element