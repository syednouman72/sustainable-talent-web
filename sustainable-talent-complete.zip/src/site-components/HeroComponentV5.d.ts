import * as React from "react";

declare function HeroComponentV5(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element