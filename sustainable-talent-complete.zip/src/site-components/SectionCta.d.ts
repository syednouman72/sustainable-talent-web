import * as React from "react";

declare function SectionCta(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element