import * as React from "react";

declare function HeroComponentV6(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element