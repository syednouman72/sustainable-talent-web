import * as React from "react";

declare function HeroComponentV2(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element